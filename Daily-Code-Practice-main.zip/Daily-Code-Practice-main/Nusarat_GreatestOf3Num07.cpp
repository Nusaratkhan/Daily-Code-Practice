#include<iostream>
using namespace std;
int main(){
    int a,b,c;
    cin>>a,b,c;
    if(a>b && a>c)
        cout<<"A is the greates Number";
    else if(b>a && b>c)
        cout<<"B is the greates Number";
    else
        cout<<"C is the greates Number";

        return 0;
        
    }