#include<iostream>
using namespace std;
int main(){
    int n;
    cin>>n;

    n%2==0? cout<<"Even Number":cout<<"Odd Number";
    return 0;
}