#include<iostream>
using namespace std;
int main(){
    int a,b;
    cin>>a>>b;
    (a>b)?cout<<"Greatest Number is: "<<a :cout<<"Greatest Number is: "<<b ;
    return 0;
}